<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="col-md-6 col-md-offset-2">
		<form class="form-horizontal" method="PUT" action="<?php echo e(route('update', $statusUpdate->id)); ?>">
		<?php echo e(csrf_field()); ?>

			<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
		        <label for="name" class="col-md-4 control-label">Name</label>

		        <div class="col-md-6">
		            <input id="name" type="text" class="form-control" name="name" value="<?php echo e($statusUpdate->name); ?>" autofocus>

		            <?php if($errors->has('name')): ?>
		                <span class="help-block">
		                    <strong><?php echo e($errors->first('name')); ?></strong>
		                </span>
		            <?php endif; ?>
		        </div>
		    </div>

		    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
		        <label for="email" class="col-md-4 control-label">Father's Name</label>

		        <div class="col-md-6">
		            <input id="fname" type="text" class="form-control" name="fname" value="<?php echo e($statusUpdate->fname); ?>">

		            <?php if($errors->has('fname')): ?>
		                <span class="help-block">
		                    <strong><?php echo e($errors->first('fname')); ?></strong>
		                </span>
		            <?php endif; ?>
		        </div>
		    </div>

		    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
		        <label for="password" class="col-md-4 control-label">Address</label>

		        <div class="col-md-6">
		            <input id="address" type="text" class="form-control" name="address" value="<?php echo e($statusUpdate->address); ?>">

		            <?php if($errors->has('address')): ?>
		                <span class="help-block">
		                    <strong><?php echo e($errors->first('address')); ?></strong>
		                </span>
		            <?php endif; ?>
		        </div>
		    </div>

		    <div class="form-group">
	            <div class="col-md-6 col-md-offset-4">
	                <button type="submit" class="btn btn-primary">
	                    Update
	                </button>
	            </div>
	        </div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>