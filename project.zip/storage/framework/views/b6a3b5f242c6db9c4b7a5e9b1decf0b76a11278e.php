<?php $__env->startSection('content'); ?>
<?php echo $__env->make('themes.pages.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Section
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Section</a></li>
        <li class="active">Add Section</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <form role="form" action="<?php echo e(route('section.store')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <!-- form start -->            
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Section Name</label>
                  <input type="text" name="section_name" class="form-control" placeholder="Section Name">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Class</label>
                  <select name="class_id" class="form-control">
                    <option>Select Class</option>
                    <?php $__currentLoopData = $allClass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $print): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($print->id); ?>"><?php echo e($print->class_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Teacher Name</label>
                  <select name="teacher_name" class="form-control">
                    <option>Select Teacher</option>
                    <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $print): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($print->fname); ?> <?php echo e($print->lname); ?>"><?php echo e($print->fname); ?> <?php echo e($print->lname); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            
          </div>
        </div> 
      </form>
      </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>