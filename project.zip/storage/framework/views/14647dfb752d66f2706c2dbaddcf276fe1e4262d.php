<?php $__env->startSection('content'); ?>
<?php echo $__env->make('themes.pages.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add Student
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Student</a></li>
        <li class="active">Add Student</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
          <div class="col-md-8">
          <div class="box box-primary">
            <table id="" class="table">
                  <tr>
                    
                    <th><img src="<?php echo e(asset('storage/'.$all->photo)); ?>" height="200px" width="280px" alt="loading"></th>
                  </tr>
                  <tr>
                    <th style="width: 25%;">Name</th>
                    <td><?php echo e($all->name); ?></td>
                  </tr>
                  <tr>
                    <th style="width: 30%;">Father's Name</th>
                    <td><?php echo e($all->fname); ?></td>
                  </tr>
                  <tr>                    
                    <th style="width: 30%;">Address</th>
                    <td><?php echo e($all->address); ?></td>
                  </tr>
                  <tr>                  
                    <th style="width: 30%;">Class</th>
                    <td><?php echo e($all->classes); ?></td>
                  </tr>

                  <tr>
                    <th style="width: 30%;">Section</th>
                    <td><?php echo e($all->section); ?></td>
                  </tr>

                  <tr>
                    <th style="width: 30%;">Department</th>
                    <td><?php echo e($all->dept); ?></td>
                  </tr>

                  <tr>
                    <th >Phone</th>
                    <td><?php echo e($all->phone); ?></td>  
                  </tr>
              </table>            
          </div>
        </div> 
      </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>